// api/claude.js
// Vercel Edge Function — proxies Anthropic API calls.
// The ANTHROPIC_API_KEY env var lives only on the server; never sent to the browser.

export const config = { runtime: 'edge' };

export default async function handler(req) {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'ANTHROPIC_API_KEY not configured on server.' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Forward to Anthropic, streaming
  const upstream = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type':         'application/json',
      'x-api-key':            apiKey,
      'anthropic-version':    '2023-06-01',
      'anthropic-beta':       'messages-2023-12-15',
    },
    body: JSON.stringify(body),
  });

  // Stream the response straight back to the browser
  return new Response(upstream.body, {
    status: upstream.status,
    headers: {
      'Content-Type':                  upstream.headers.get('Content-Type') || 'text/event-stream',
      'Access-Control-Allow-Origin':   '*',
      'Cache-Control':                 'no-cache',
      'X-Accel-Buffering':             'no',
    },
  });
}
