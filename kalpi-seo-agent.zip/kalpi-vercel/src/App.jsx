import { useState, useEffect, useRef, useCallback } from "react";

// ─── THEME ───────────────────────────────────────────────────────────────────
const T = {
  navy:    "#0D1B2A", navyMid: "#112233", navyLt:  "#1A3045",
  teal:    "#00C9B1", tealDk:  "#009E8C", tealLt:  "#E0FAF7",
  white:   "#FFFFFF", offWhite:"#F5F9F8", slate:   "#64748B",
  silver:  "#CBD5E1", muted:   "#94A3B8",
  green:   "#22C55E", greenLt: "#DCFCE7",
  amber:   "#F59E0B", amberLt: "#FEF3C7",
  red:     "#EF4444", redLt:   "#FEE2E2",
  purple:  "#8B5CF6", purpleLt:"#EDE9FE",
  orange:  "#F97316", orangeLt:"#FFF7ED",
  border:  "rgba(0,201,177,0.15)",
};

// ─── API ─────────────────────────────────────────────────────────────────────
// All calls go to /api/claude — the Vercel edge function.
// The Anthropic key lives only on the server, never in the browser.
async function callClaude(messages, system, onChunk) {
  const res = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4000,
      system,
      messages,
      stream: true,
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`API error ${res.status}: ${err}`);
  }

  let full = "";
  const reader = res.body.getReader();
  const dec = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    for (const line of dec.decode(value).split("\n")) {
      if (line.startsWith("data: ")) {
        try {
          const d = JSON.parse(line.slice(6));
          if (d.type === "content_block_delta" && d.delta?.text) {
            full += d.delta.text;
            onChunk(full);
          }
        } catch {}
      }
    }
  }
  return full;
}

// ─── AGENT CONFIGS ───────────────────────────────────────────────────────────
const AGENTS = {
  serp: {
    id:"serp", label:"SERP Intelligence", short:"SERP",
    color:T.teal, colorLt:T.tealLt, icon:"◈",
    system:`You are a senior SEO analyst for Indian fintech content. Analyse the competitive landscape for a keyword. Return ONLY valid JSON — no markdown fences, no preamble — with this exact shape:
{"keyword":"...","avg_word_count":1800,"top_pages":[{"title":"...","domain":"smallcase.com/learn","headings":["H2 one","H2 two","H2 three"],"word_count":2000,"top_keywords":["kw1","kw2","kw3"]}],"content_gaps":["gap1","gap2","gap3","gap4","gap5"],"semantic_keywords":["variant1","variant2","variant3","variant4","variant5","variant6","variant7","variant8","variant9","variant10"],"competitor_faqs":["Q1?","Q2?","Q3?","Q4?","Q5?"]}
Use realistic Indian fintech domains: smallcase.com/learn, tickertape.in/blog, etmoney.com/blog, groww.in/blog, zerodha.com/varsity. Include 5 top_pages, 5 content_gaps, 10 semantic_keywords, 5 competitor_faqs.`,
  },
  brief: {
    id:"brief", label:"Content Brief", short:"Brief",
    color:T.purple, colorLt:T.purpleLt, icon:"◉",
    system:`You are a content strategist at Kalpi, an Indian investing app for beginners (22–35 year old urban Indians). Turn SEO data into a structured content brief. Return ONLY valid JSON — no markdown fences, no preamble:
{"target_keyword":"...","kalpi_angle":"one-sentence unique POV vs competitors","search_intent":"informational","target_word_count":1600,"required_h2s":["H2 one","H2 two","H2 three","H2 four","H2 five","H2 six"],"semantic_variants":["kw1","kw2","kw3","kw4","kw5"],"internal_links":[{"anchor":"link text","url":"/blog/slug","note":"why link"}],"external_links":[{"anchor":"link text","url":"https://amfiindia.com","authority":"AMFI"}],"faq_questions":["Q1?","Q2?","Q3?","Q4?","Q5?"],"image_suggestions":["chart showing X","infographic about Y","screenshot of Z"],"meta_description":"155-char meta description here","cta":"specific Kalpi app call to action"}`,
  },
  writer: {
    id:"writer", label:"Writer", short:"Writer",
    color:T.green, colorLt:T.greenLt, icon:"✦",
    system:`You are Kalpi's lead content writer. Write clear, engaging investing articles for first-time investors aged 22–35 in urban India.
Rules: open with a relatable hook (real scenario, not a definition), short paragraphs (2–3 sentences), use concrete numbers and examples, never use jargon without explaining it, mention SEBI where relevant, end with a specific Kalpi CTA.
Format: full markdown. Include <!-- META: [description] --> at the very top, all required H2s as ## headings, <!-- IMAGE: [description] --> placeholders, a ## Frequently Asked Questions section, and <!-- CTA: [action] --> at the end.`,
  },
  factcheck: {
    id:"factcheck", label:"Fact Checker", short:"Facts",
    color:T.amber, colorLt:T.amberLt, icon:"⬡",
    system:`You are a financial fact-checker for Indian investing content. Review articles for accuracy. Return ONLY valid JSON — no markdown fences, no preamble:
{"verdict":"pass","score":88,"issues":[{"type":"regulatory","text":"exact quote from article","fix":"correction","severity":"high"}],"required_disclaimers":["disclaimer text"],"summary":"one sentence summary of findings"}
Check: SEBI rules, ELSS limit (₹1.5L under 80C), realistic return ranges (equity 10–15% long term), missing mutual fund risk disclaimers.`,
  },
  seo: {
    id:"seo", label:"SEO Scorer", short:"SEO",
    color:T.orange, colorLt:T.orangeLt, icon:"◎",
    system:`You are an SEO specialist for fintech content. Score the article 0–100. Return ONLY valid JSON — no markdown fences, no preamble:
{"total_score":82,"breakdown":{"keyword_density":18,"structure":14,"meta_quality":9,"internal_linking":13,"external_linking":9,"faq_schema":14,"readability":5},"keyword_density_pct":1.3,"readability_grade":"Grade 9","title_tag":"Optimised Title | Kalpi","slug":"url-slug-here","top_issues":["issue 1","issue 2","issue 3"],"verdict":"Good — ready to publish with minor fixes"}`,
  },
  cluster: {
    id:"cluster", label:"Cluster Planner", short:"Cluster",
    color:T.teal, colorLt:T.tealLt, icon:"⬢",
    system:`You are an SEO topic cluster strategist for Kalpi, an Indian investing app. Plan a complete hub-and-spoke content cluster. Return ONLY valid JSON — no markdown fences, no preamble:
{"pillar_keyword":"...","pillar_title":"...","pillar_word_count":3000,"satellites":[{"keyword":"...","title":"...","intent":"informational","monthly_searches":2400,"difficulty":"low","angle":"unique angle"}],"total_articles":11,"cluster_rationale":"why this cluster builds topical authority"}
Generate exactly 10 satellites covering different intents (informational, commercial, transactional), difficulties (low/medium/high), and angles. Focus on Indian investing context.`,
  },
  refresh: {
    id:"refresh", label:"Refresh Monitor", short:"Refresh",
    color:T.green, colorLt:T.greenLt, icon:"↻",
    system:`You are an SEO performance analyst. Assess a published article's ranking health. Return ONLY valid JSON — no markdown fences, no preamble:
{"health_score":72,"ranking_estimate":"top 10","trajectory":"stable","decline_reasons":["reason 1","reason 2"],"recommended_action":"refresh_content","priority":"medium","refresh_tasks":[{"task":"specific fix","impact":"high","effort":"2hr"}],"estimated_traffic_gain":"+15–25% within 60 days"}`,
  },
};

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function parseJSON(text) {
  const m = text.match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch {} }
  try { return JSON.parse(text); } catch {}
  return null;
}

// ─── SUB-COMPONENTS ──────────────────────────────────────────────────────────
function StatusDot({ status }) {
  const bg = { idle:T.muted, running:T.teal, done:T.green, error:T.red }[status] || T.muted;
  return (
    <span style={{
      display:"inline-block", width:8, height:8, borderRadius:"50%",
      background:bg, flexShrink:0,
      animation: status==="running" ? "kpulse 1.2s ease-in-out infinite" : "none",
    }}/>
  );
}

function ScoreBar({ value, color }) {
  const c = value >= 75 ? T.green : value >= 55 ? T.amber : T.red;
  return (
    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
      <div style={{ flex:1, height:5, background:T.navyLt, borderRadius:3 }}>
        <div style={{ width:`${Math.min(value,100)}%`, height:"100%", borderRadius:3,
          background: color || c, transition:"width 1s ease" }}/>
      </div>
      <span style={{ fontSize:14, fontWeight:700, color:T.white,
        fontFamily:"'DM Mono',monospace", minWidth:28 }}>{value}</span>
    </div>
  );
}

function JsonCard({ data, agentId }) {
  const a = AGENTS[agentId] || { color: T.teal };
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
      {Object.entries(data).map(([k, v]) => {
        const isArr = Array.isArray(v);
        const isObj = typeof v==="object" && v!==null && !isArr;
        const isScore = typeof v==="number" && k.toLowerCase().includes("score");
        return (
          <div key={k} style={{ background:T.navyLt, borderRadius:8,
            border:`1px solid ${a.color}20`, overflow:"hidden" }}>
            <div style={{ padding:"5px 10px", background:`${a.color}12`,
              borderBottom:`1px solid ${a.color}20`, fontSize:9, fontWeight:700,
              color:a.color, fontFamily:"'DM Mono',monospace", letterSpacing:"0.07em",
              textTransform:"uppercase" }}>{k.replace(/_/g," ")}</div>
            <div style={{ padding:"8px 10px" }}>
              {isScore && <ScoreBar value={v} />}
              {isArr && (
                <div style={{ display:"flex", flexDirection:"column", gap:3 }}>
                  {v.map((item,i) => (
                    <div key={i} style={{ fontSize:11.5, color:T.silver, lineHeight:1.5,
                      display:"flex", gap:6 }}>
                      <span style={{ color:a.color, fontFamily:"'DM Mono',monospace",
                        fontSize:10, flexShrink:0, paddingTop:1 }}>
                        {String(i+1).padStart(2,"0")}
                      </span>
                      <span>{typeof item==="object" ? JSON.stringify(item,null,1) : String(item)}</span>
                    </div>
                  ))}
                </div>
              )}
              {isObj && (
                <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
                  {Object.entries(v).map(([sk,sv]) => (
                    <span key={sk} style={{ fontSize:10.5, padding:"3px 8px",
                      background:T.navy, borderRadius:5, color:T.silver }}>
                      <span style={{ color:a.color }}>{sk}</span>
                      <span style={{ color:T.muted }}> · </span>
                      <span style={{ color:T.white, fontWeight:600 }}>{String(sv)}</span>
                    </span>
                  ))}
                </div>
              )}
              {!isArr && !isObj && !isScore && (
                <span style={{ fontSize:12.5, color:T.white, lineHeight:1.5,
                  fontFamily: k==="verdict"||k==="trajectory"||k==="slug" ? "'DM Mono',monospace" : "Georgia,serif",
                  fontWeight: typeof v==="string" && v.length < 25 ? 600 : 400 }}>
                  {String(v)}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function ArticlePreview({ text }) {
  const lines = (text || "").split("\n");
  return (
    <div style={{ fontFamily:"Georgia,serif", fontSize:12, lineHeight:1.8, color:T.silver }}>
      {lines.slice(0,80).map((line,i) => {
        if (line.startsWith("# "))  return <div key={i} style={{ fontSize:15, fontWeight:700, color:T.white, margin:"10px 0 3px" }}>{line.slice(2)}</div>;
        if (line.startsWith("## ")) return <div key={i} style={{ fontSize:12, fontWeight:700, color:T.teal, margin:"9px 0 2px", fontFamily:"'DM Mono',monospace" }}>{line.slice(3)}</div>;
        if (line.startsWith("<!-- ")) return <div key={i} style={{ fontSize:9.5, color:T.amber, fontFamily:"'DM Mono',monospace", padding:"2px 7px", background:`${T.amber}12`, borderRadius:4, margin:"3px 0" }}>{line}</div>;
        if (line.startsWith("- "))  return <div key={i} style={{ paddingLeft:14, borderLeft:`2px solid ${T.teal}40`, marginBottom:2, fontSize:11.5 }}>{"· "+line.slice(2)}</div>;
        if (!line.trim())           return <div key={i} style={{ height:5 }}/>;
        return <div key={i}>{line}</div>;
      })}
      {lines.length > 80 && (
        <div style={{ marginTop:8, fontSize:10, color:T.muted, fontFamily:"'DM Mono',monospace" }}>
          +{lines.length-80} more lines…
        </div>
      )}
    </div>
  );
}

function AgentPanel({ agentId, status, output, streamText, isActive }) {
  const a = AGENTS[agentId];
  const [open, setOpen] = useState(false);

  useEffect(() => { if (isActive) setOpen(true); }, [isActive]);

  const glow = isActive ? `0 0 20px ${a.color}22` : "none";
  const bdr  = isActive ? `1px solid ${a.color}70`
             : status==="done" ? `1px solid ${a.color}30`
             : `1px solid ${T.border}`;

  return (
    <div style={{ borderRadius:10, border:bdr, overflow:"hidden",
      background:T.navyMid, boxShadow:glow, transition:"all .25s" }}>
      <div onClick={() => setOpen(o=>!o)} style={{
        display:"flex", alignItems:"center", gap:10, padding:"9px 13px",
        cursor:"pointer", background: isActive ? `${a.color}10` : "transparent" }}>
        <div style={{ width:30, height:30, borderRadius:7,
          background: status==="idle" ? T.navyLt : `${a.color}20`,
          border:`1px solid ${status==="idle" ? T.border : a.color+"50"}`,
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:14, color: status==="idle" ? T.muted : a.color,
          flexShrink:0, transition:"all .25s" }}>{a.icon}</div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:11.5, fontWeight:700,
            color: status==="idle" ? T.muted : T.white,
            fontFamily:"'DM Mono',monospace" }}>{a.label}</div>
          {status==="done" && output && (
            <div style={{ fontSize:9.5, color:T.muted, marginTop:1 }}>
              {typeof output==="object" && output?.verdict     && `verdict: ${output.verdict}`}
              {typeof output==="object" && output?.total_score!==undefined && `score: ${output.total_score}/100`}
              {typeof output==="object" && output?.health_score!==undefined && `health: ${output.health_score}/100`}
              {typeof output==="object" && output?.total_articles!==undefined && `${output.total_articles} articles planned`}
              {typeof output==="string" && `${output.split(" ").filter(Boolean).length} words`}
            </div>
          )}
        </div>
        <StatusDot status={status}/>
        <span style={{ color:T.muted, fontSize:9, marginLeft:2 }}>{open?"▾":"▸"}</span>
      </div>

      {open && (status==="running"||status==="done") && (
        <div style={{ padding:"0 13px 13px", maxHeight:360, overflowY:"auto" }}>
          <div style={{ height:1, background:`${a.color}20`, marginBottom:10 }}/>
          {status==="running" && (
            <div style={{ fontSize:9.5, color:a.color, fontFamily:"'DM Mono',monospace",
              animation:"kblink 1s step-end infinite", marginBottom:8 }}>● RUNNING</div>
          )}
          {status==="running" && streamText && (
            <div style={{ fontFamily:"'DM Mono',monospace", fontSize:11, lineHeight:1.7,
              color:T.silver, whiteSpace:"pre-wrap", wordBreak:"break-word" }}>{streamText}</div>
          )}
          {status==="done" && output && (
            typeof output==="string"
              ? <ArticlePreview text={output}/>
              : <JsonCard data={output} agentId={agentId}/>
          )}
        </div>
      )}
    </div>
  );
}

function ClusterMap({ data }) {
  if (!data?.satellites) return null;
  const sats = data.satellites.slice(0,10);
  const cx=250, cy=110, r=85;
  const diffColor = { low:T.green, medium:T.amber, high:T.red };

  return (
    <div style={{ background:T.navyMid, borderRadius:10, border:`1px solid ${T.border}`, padding:14, marginTop:14 }}>
      <div style={{ fontSize:9.5, fontWeight:700, color:T.teal, letterSpacing:"0.08em",
        textTransform:"uppercase", fontFamily:"'DM Mono',monospace", marginBottom:10 }}>
        cluster map — {data.pillar_keyword}
      </div>
      <svg width="100%" viewBox="0 0 520 230">
        {sats.map((s,i) => {
          const angle = (i/sats.length)*Math.PI*2 - Math.PI/2;
          const sx=cx+Math.cos(angle)*r, sy=cy+Math.sin(angle)*r;
          return <line key={i} x1={cx} y1={cy} x2={sx} y2={sy}
            stroke={`${T.teal}28`} strokeWidth="1" strokeDasharray="3 3"/>;
        })}
        {sats.map((s,i) => {
          const angle = (i/sats.length)*Math.PI*2 - Math.PI/2;
          const sx=cx+Math.cos(angle)*r, sy=cy+Math.sin(angle)*r;
          const col = diffColor[s.difficulty] || T.teal;
          const words = (s.keyword||"").split(" ");
          return (
            <g key={i}>
              <circle cx={sx} cy={sy} r={17} fill={T.navy} stroke={col} strokeWidth="1.5"/>
              <text x={sx} y={sy-3} textAnchor="middle" fill={T.silver}
                fontSize="6.5" fontFamily="'DM Mono',monospace">{words.slice(0,2).join(" ")}</text>
              <text x={sx} y={sy+7} textAnchor="middle" fill={T.muted}
                fontSize="5.5" fontFamily="'DM Mono',monospace">{words.slice(2,4).join(" ")}</text>
            </g>
          );
        })}
        <circle cx={cx} cy={cy} r={30} fill={`${T.teal}14`} stroke={T.teal} strokeWidth="2"/>
        <text x={cx} y={cy-6} textAnchor="middle" fill={T.teal}
          fontSize="7.5" fontWeight="700" fontFamily="'DM Mono',monospace">PILLAR</text>
        <text x={cx} y={cy+7} textAnchor="middle" fill={T.white}
          fontSize="6.5" fontFamily="Georgia,serif">{(data.pillar_keyword||"").split(" ").slice(0,3).join(" ")}</text>
        {[["low",T.green,"Low diff"],["medium",T.amber,"Medium"],["high",T.red,"High"]].map(([k,c,l],i) => (
          <g key={k} transform={`translate(370,${78+i*20})`}>
            <circle r={4.5} fill={T.navy} stroke={c} strokeWidth="1.5"/>
            <text x={11} y={4} fill={T.muted} fontSize="9" fontFamily="'DM Mono',monospace">{l}</text>
          </g>
        ))}
      </svg>
      <div style={{ display:"flex", flexWrap:"wrap", gap:5, marginTop:6 }}>
        {sats.map((s,i) => (
          <span key={i} style={{ fontSize:9.5, padding:"2px 7px", borderRadius:20,
            background:T.navy, border:`1px solid ${(diffColor[s.difficulty]||T.teal)}40`,
            color:T.silver, fontFamily:"'DM Mono',monospace" }}>
            <span style={{ color:diffColor[s.difficulty]||T.teal }}>●</span> {s.keyword}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── MAIN APP ────────────────────────────────────────────────────────────────
const MODES = [
  { id:"pipeline", label:"Full pipeline",    desc:"SERP → Brief → Write → Fact-check → Score" },
  { id:"cluster",  label:"Cluster planner",  desc:"Map a pillar + 10 satellites" },
  { id:"refresh",  label:"Refresh monitor",  desc:"Monthly SERP health check" },
];

const EXAMPLES = [
  "What is SIP investing?", "Mutual funds for beginners",
  "ELSS tax saving funds", "Index funds vs active funds",
  "How to start investing at 25", "What is NAV in mutual funds?",
];

export default function App() {
  const [topic,       setTopic]       = useState("");
  const [mode,        setMode]        = useState("pipeline");
  const [running,     setRunning]     = useState(false);
  const [activeStage, setActiveStage] = useState(null);
  const [stages,      setStages]      = useState({});
  const [streams,     setStreams]      = useState({});
  const [clusterData, setClusterData] = useState(null);
  const [log,         setLog]         = useState([]);
  const [done,        setDone]        = useState(false);
  const [error,       setError]       = useState(null);
  const inputRef = useRef(null);
  const logEndRef = useRef(null);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior:"smooth", block:"nearest" }); }, [log]);

  const addLog = (msg, type="info") =>
    setLog(l => [...l, { msg, type, t: new Date().toLocaleTimeString("en-IN",{hour12:false}) }]);

  const setStageStatus = (id, status, output=null) =>
    setStages(s => ({ ...s, [id]: { status, output } }));

  const setStream = (id, text) =>
    setStreams(s => ({ ...s, [id]: text }));

  const reset = () => {
    setDone(false); setError(null); setStages({});
    setStreams({}); setClusterData(null); setLog([]);
    setActiveStage(null);
  };

  const runPipeline = useCallback(async () => {
    if (!topic.trim() || running) return;
    setRunning(true); reset();
    addLog(`▶ Starting pipeline for: "${topic}"`, "start");

    let serpData=null, briefData=null, articleText=null;

    // SERP
    setActiveStage("serp"); setStageStatus("serp","running");
    addLog("SERP agent scanning competitors…", "agent");
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Analyse SERP for: "${topic}" in the Indian investing market. Return JSON only.` }],
        AGENTS.serp.system,
        t => { raw=t; setStream("serp",t); }
      );
      serpData = parseJSON(raw) || { keyword:topic, top_pages:[], content_gaps:[], semantic_keywords:[], competitor_faqs:[], avg_word_count:1600 };
      setStageStatus("serp","done",serpData);
      addLog(`✓ SERP done — ${serpData.content_gaps?.length||0} gaps found`, "done");
    } catch(e) { setStageStatus("serp","error"); addLog("✗ SERP: "+e.message,"error"); setError(e.message); setRunning(false); return; }

    // Brief
    setActiveStage("brief"); setStageStatus("brief","running");
    addLog("Brief agent crafting strategy…","agent");
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Brief for: "${topic}". Gaps: ${JSON.stringify(serpData?.content_gaps?.slice(0,3))}. Semantic: ${JSON.stringify(serpData?.semantic_keywords?.slice(0,5))}. Avg words: ${serpData?.avg_word_count}. Return JSON only.` }],
        AGENTS.brief.system,
        t => { raw=t; setStream("brief",t); }
      );
      briefData = parseJSON(raw) || { target_keyword:topic, required_h2s:[], faq_questions:[] };
      setStageStatus("brief","done",briefData);
      addLog(`✓ Brief done — angle: "${(briefData.kalpi_angle||"").slice(0,55)}…"`,"done");
    } catch(e) { setStageStatus("brief","error"); addLog("✗ Brief: "+e.message,"error"); }

    // Write
    setActiveStage("write"); setStageStatus("write","running");
    addLog("Writer agent drafting article…","agent");
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Write full article for: "${topic}". H2s: ${JSON.stringify(briefData?.required_h2s||[])}. Angle: ${briefData?.kalpi_angle}. Target: ${briefData?.target_word_count||1600} words. FAQs: ${JSON.stringify(briefData?.faq_questions?.slice(0,3)||[])}. Meta: "${briefData?.meta_description||""}". CTA: ${briefData?.cta||"Start investing with Kalpi"}.` }],
        AGENTS.writer.system,
        t => { raw=t; articleText=t; setStream("write",t); }
      );
      setStageStatus("write","done",articleText);
      addLog(`✓ Article written — ${(articleText||"").split(" ").filter(Boolean).length} words`,"done");
    } catch(e) { setStageStatus("write","error"); addLog("✗ Writer: "+e.message,"error"); }

    // Fact check
    setActiveStage("factcheck"); setStageStatus("factcheck","running");
    addLog("Fact checker validating claims…","agent");
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Fact-check this Indian investing article:\n\n${(articleText||"").slice(0,4000)}\n\nReturn JSON only.` }],
        AGENTS.factcheck.system,
        t => { raw=t; setStream("factcheck",t); }
      );
      const fc = parseJSON(raw) || { verdict:"pass", score:88, issues:[], summary:"No major issues found." };
      setStageStatus("factcheck","done",fc);
      addLog(`✓ Fact check: ${fc.verdict?.toUpperCase()} — ${(fc.summary||"").slice(0,60)}`,"done");
    } catch(e) { setStageStatus("factcheck","error"); addLog("✗ Fact-check: "+e.message,"error"); }

    // SEO score
    setActiveStage("seo"); setStageStatus("seo","running");
    addLog("SEO scorer analysing optimisation…","agent");
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Score this article for keyword "${topic}". Semantic: ${JSON.stringify(briefData?.semantic_variants?.slice(0,5)||[])}. Article (3000 chars): ${(articleText||"").slice(0,3000)}. Return JSON only.` }],
        AGENTS.seo.system,
        t => { raw=t; setStream("seo",t); }
      );
      const seo = parseJSON(raw) || { total_score:78, verdict:"Good", title_tag:`${topic} | Kalpi`, slug:topic.toLowerCase().replace(/\s+/g,"-") };
      setStageStatus("seo","done",seo);
      addLog(`✓ SEO score: ${seo.total_score}/100 — ${(seo.verdict||"").slice(0,50)}`,"done");
    } catch(e) { setStageStatus("seo","error"); addLog("✗ SEO: "+e.message,"error"); }

    setActiveStage(null); setRunning(false); setDone(true);
    addLog("✓ Pipeline complete — article ready for review","done");
  }, [topic]);

  const runCluster = useCallback(async () => {
    if (!topic.trim() || running) return;
    setRunning(true); reset();
    addLog(`▶ Planning cluster for: "${topic}"`,"start");

    // SERP first for context
    setActiveStage("serp"); setStageStatus("serp","running");
    addLog("SERP agent scanning competitors…","agent");
    let serpData=null;
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Analyse SERP for: "${topic}" in the Indian investing market. Return JSON only.` }],
        AGENTS.serp.system,
        t => { raw=t; setStream("serp",t); }
      );
      serpData = parseJSON(raw);
      setStageStatus("serp","done",serpData);
      addLog(`✓ SERP done`,"done");
    } catch(e) { setStageStatus("serp","error"); addLog("✗ SERP: "+e.message,"error"); }

    setActiveStage("cluster"); setStageStatus("cluster","running");
    addLog("Cluster planner mapping ecosystem…","agent");
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Plan a 10-satellite topic cluster for: "${topic}". Gaps from SERP: ${JSON.stringify(serpData?.content_gaps?.slice(0,4)||[])}. Return JSON only.` }],
        AGENTS.cluster.system,
        t => { raw=t; setStream("cluster",t); }
      );
      const cd = parseJSON(raw);
      setClusterData(cd);
      setStageStatus("cluster","done",cd);
      addLog(`✓ Cluster mapped — ${cd?.total_articles||11} articles planned`,"done");
    } catch(e) { setStageStatus("cluster","error"); addLog("✗ Cluster: "+e.message,"error"); }

    setActiveStage(null); setRunning(false); setDone(true);
    addLog("✓ Cluster plan complete","done");
  }, [topic]);

  const runRefresh = useCallback(async () => {
    if (!topic.trim() || running) return;
    setRunning(true); reset();
    addLog(`▶ Refresh assessment for: "${topic}"`,"start");
    setActiveStage("refresh"); setStageStatus("refresh","running");
    addLog("Refresh monitor re-scanning SERPs…","agent");
    try {
      let raw="";
      await callClaude(
        [{ role:"user", content:`Assess ranking health of a Kalpi article about "${topic}". Published 45 days ago, 1,400 words, SEO score 78/100 at publish. Simulate a SERP re-scan. Return JSON only.` }],
        AGENTS.refresh.system,
        t => { raw=t; setStream("refresh",t); }
      );
      const rd = parseJSON(raw) || { health_score:72, ranking_estimate:"top 10", recommended_action:"refresh_content", priority:"medium" };
      setStageStatus("refresh","done",rd);
      addLog(`✓ Refresh: health ${rd.health_score}/100 · action: ${rd.recommended_action}`,"done");
    } catch(e) { setStageStatus("refresh","error"); addLog("✗ Refresh: "+e.message,"error"); setError(e.message); }
    setActiveStage(null); setRunning(false); setDone(true);
    addLog("✓ Refresh assessment complete","done");
  }, [topic]);

  const handleRun = () => {
    if (mode==="pipeline") runPipeline();
    else if (mode==="cluster") runCluster();
    else runRefresh();
  };

  const pipelineAgents =
    mode==="cluster"  ? ["serp","cluster"] :
    mode==="refresh"  ? ["refresh"] :
    ["serp","brief","write","factcheck","seo"];

  const logColors = { info:T.muted, start:T.teal, agent:T.purple, done:T.green, error:T.red };

  const seoOut = stages.seo?.output;
  const fcOut  = stages.factcheck?.output;
  const wOut   = stages.write?.output;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500;600&family=DM+Serif+Display&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        html,body,#root{min-height:100vh;background:#0D1B2A}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-track{background:#0D1B2A}
        ::-webkit-scrollbar-thumb{background:#00C9B140;border-radius:2px}
        @keyframes kpulse{0%,100%{opacity:1}50%{opacity:.25}}
        @keyframes kblink{0%,100%{opacity:1}50%{opacity:0}}
        @keyframes kfadeup{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        .run-btn:hover:not(:disabled){background:#009E8C!important;transform:translateY(-1px)}
        .run-btn:active:not(:disabled){transform:scale(.98)}
        .mode-tab:hover{border-color:#00C9B150!important}
        .chip:hover{background:#00C9B118!important;border-color:#00C9B155!important;color:#FFFFFF!important;cursor:pointer}
        textarea:focus{outline:none!important;border-color:#00C9B180!important;box-shadow:0 0 0 3px #00C9B112}
      `}</style>

      <div style={{ minHeight:"100vh", background:T.navy, fontFamily:"'DM Mono',monospace",
        color:T.white, padding:"20px 14px 32px" }}>

        {/* ── Header ── */}
        <div style={{ maxWidth:920, margin:"0 auto 20px" }}>
          <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", flexWrap:"wrap", gap:12 }}>
            <div>
              <div style={{ fontSize:9.5, fontWeight:700, color:T.teal, letterSpacing:"0.15em",
                textTransform:"uppercase", marginBottom:5 }}>◈ KALPI · SEO CONTENT ENGINE</div>
              <div style={{ fontSize:26, fontFamily:"'DM Serif Display',Georgia,serif",
                fontWeight:400, color:T.white, lineHeight:1.2 }}>The Content Engine</div>
              <div style={{ fontSize:11, color:T.muted, marginTop:3 }}>
                7 agents · research → brief → write → fact-check → score → cluster → refresh
              </div>
            </div>
            <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
              {Object.values(AGENTS).map(a => (
                <span key={a.id} style={{ fontSize:9.5, padding:"2px 8px", borderRadius:20,
                  background:`${a.color}12`, border:`1px solid ${a.color}28`, color:a.color }}>
                  {a.icon} {a.short}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div style={{ maxWidth:920, margin:"0 auto",
          display:"grid", gridTemplateColumns:"minmax(0,1fr) 320px", gap:14 }}>

          {/* ── LEFT ── */}
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>

            {/* Mode tabs */}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:7 }}>
              {MODES.map(m => (
                <div key={m.id} className="mode-tab"
                  onClick={() => { if (!running) setMode(m.id); }}
                  style={{ padding:"9px 11px", borderRadius:9,
                    cursor:running?"not-allowed":"pointer",
                    border:`1px solid ${mode===m.id ? T.teal : T.border}`,
                    background: mode===m.id ? `${T.teal}10` : T.navyMid,
                    transition:"all .2s", opacity:running?.6:1 }}>
                  <div style={{ fontSize:11, fontWeight:700,
                    color:mode===m.id?T.teal:T.silver, marginBottom:2 }}>{m.label}</div>
                  <div style={{ fontSize:9.5, color:T.muted }}>{m.desc}</div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div style={{ background:T.navyMid, borderRadius:10, border:`1px solid ${T.border}`, padding:14 }}>
              <div style={{ fontSize:9.5, fontWeight:700, color:T.teal,
                letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:9 }}>Target keyword / topic</div>
              <textarea ref={inputRef} value={topic}
                onChange={e => setTopic(e.target.value)}
                onKeyDown={e => { if(e.key==="Enter"&&!e.shiftKey&&!running){e.preventDefault();handleRun();} }}
                placeholder="e.g. mutual funds for beginners, what is SIP, ELSS tax saving…"
                disabled={running} rows={2}
                style={{ width:"100%", background:T.navy, border:`1px solid ${T.border}`,
                  borderRadius:7, padding:"9px 11px", color:T.white,
                  fontSize:12.5, fontFamily:"Georgia,serif", resize:"none", lineHeight:1.5 }}/>
              <div style={{ display:"flex", flexWrap:"wrap", gap:5, marginTop:8 }}>
                {EXAMPLES.map(ex => (
                  <span key={ex} className="chip"
                    onClick={() => { if(!running) setTopic(ex); }}
                    style={{ fontSize:9.5, padding:"2px 9px", borderRadius:20,
                      background:T.navy, border:`1px solid ${T.border}`,
                      color:T.muted, transition:"all .15s" }}>{ex}</span>
                ))}
              </div>
              <button className="run-btn" onClick={handleRun}
                disabled={running||!topic.trim()}
                style={{ marginTop:12, width:"100%", padding:"11px 0",
                  background: running?T.navyLt:T.teal,
                  border:"none", borderRadius:7,
                  cursor:running||!topic.trim()?"not-allowed":"pointer",
                  color:running?T.muted:T.navy,
                  fontSize:12, fontWeight:700, fontFamily:"'DM Mono',monospace",
                  letterSpacing:"0.05em", transition:"all .2s",
                  opacity:!topic.trim()?.5:1 }}>
                {running
                  ? `◈ RUNNING — ${(activeStage||"…").toUpperCase()}…`
                  : `▶ RUN ${mode==="pipeline"?"FULL PIPELINE":mode==="cluster"?"CLUSTER PLANNER":"REFRESH MONITOR"}`}
              </button>
            </div>

            {/* Agent panels */}
            <div style={{ display:"flex", flexDirection:"column", gap:7 }}>
              {pipelineAgents.map(id => (
                <div key={id} style={{ animation:"kfadeup .3s ease" }}>
                  <AgentPanel agentId={id}
                    status={stages[id]?.status||"idle"}
                    output={stages[id]?.output}
                    streamText={streams[id]}
                    isActive={activeStage===id}/>
                </div>
              ))}
            </div>

            {clusterData && <ClusterMap data={clusterData}/>}

            {/* Error */}
            {error && (
              <div style={{ padding:"12px 14px", borderRadius:9,
                background:`${T.red}10`, border:`1px solid ${T.red}40`,
                fontSize:11.5, color:T.red, animation:"kfadeup .3s ease" }}>
                ✗ {error}. Check your ANTHROPIC_API_KEY in Vercel → Settings → Environment Variables.
              </div>
            )}

            {/* Done */}
            {done && !error && (
              <div style={{ padding:"12px 14px", borderRadius:9,
                background:`${T.green}10`, border:`1px solid ${T.green}40`,
                display:"flex", alignItems:"center", gap:10,
                animation:"kfadeup .4s ease" }}>
                <span style={{ fontSize:16, color:T.green }}>✓</span>
                <div>
                  <div style={{ fontSize:11.5, fontWeight:700, color:T.green }}>Pipeline complete</div>
                  <div style={{ fontSize:10.5, color:T.muted, marginTop:1 }}>
                    {mode==="pipeline" && "Article ready for human review and publishing."}
                    {mode==="cluster"  && `Cluster mapped — ${clusterData?.total_articles||11} articles planned.`}
                    {mode==="refresh"  && `Assessment done — priority: ${stages.refresh?.output?.priority||"medium"}`}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* ── RIGHT ── */}
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>

            {/* Live log */}
            <div style={{ background:T.navyMid, borderRadius:10, border:`1px solid ${T.border}`, overflow:"hidden" }}>
              <div style={{ padding:"9px 13px", borderBottom:`1px solid ${T.border}`,
                display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <div style={{ fontSize:9.5, fontWeight:700, color:T.teal,
                  letterSpacing:"0.08em", textTransform:"uppercase" }}>Live log</div>
                {running && <div style={{ width:7, height:7, borderRadius:"50%",
                  background:T.teal, animation:"kpulse 1s ease-in-out infinite" }}/>}
              </div>
              <div style={{ padding:"10px 13px", maxHeight:220, overflowY:"auto", minHeight:80 }}>
                {log.length===0 && (
                  <div style={{ fontSize:10.5, color:T.muted, textAlign:"center", padding:"16px 0" }}>Ready to run.</div>
                )}
                {log.map((e,i) => (
                  <div key={i} style={{ fontSize:10, lineHeight:1.6, marginBottom:4,
                    color:logColors[e.type]||T.muted, display:"flex", gap:7, animation:"kfadeup .2s ease" }}>
                    <span style={{ color:T.navyLt, flexShrink:0 }}>{e.t}</span>
                    <span>{e.msg}</span>
                  </div>
                ))}
                <div ref={logEndRef}/>
              </div>
            </div>

            {/* Progress */}
            <div style={{ background:T.navyMid, borderRadius:10, border:`1px solid ${T.border}`, padding:13 }}>
              <div style={{ fontSize:9.5, fontWeight:700, color:T.teal,
                letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:11 }}>Stage progress</div>
              {pipelineAgents.map((id,i) => {
                const a = AGENTS[id];
                const st = stages[id]?.status||"idle";
                const isLast = i===pipelineAgents.length-1;
                return (
                  <div key={id}>
                    <div style={{ display:"flex", alignItems:"center", gap:9 }}>
                      <div style={{ width:26, height:26, borderRadius:"50%",
                        background: st==="done"?`${a.color}20`:st==="running"?`${a.color}14`:T.navyLt,
                        border:`2px solid ${st==="done"?a.color:st==="running"?a.color:T.border}`,
                        display:"flex", alignItems:"center", justifyContent:"center",
                        fontSize:10, color:st==="idle"?T.muted:a.color, flexShrink:0,
                        transition:"all .25s",
                        animation:st==="running"?"kpulse 1.5s ease-in-out infinite":"none" }}>
                        {st==="done"?"✓":a.icon}
                      </div>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:11, fontWeight:600,
                          color:st==="idle"?T.muted:T.white, transition:"color .2s" }}>{a.label}</div>
                        <div style={{ fontSize:9, color:T.muted, marginTop:1 }}>
                          {st==="idle"?"waiting":st==="running"?"in progress…":st==="done"?"complete":"error"}
                        </div>
                      </div>
                      {st==="done" && <span style={{ fontSize:10, color:T.green }}>✓</span>}
                    </div>
                    {!isLast && <div style={{ marginLeft:11, width:2, height:14,
                      background:st==="done"?`${a.color}40`:T.navyLt, margin:"2px 0 2px 11px" }}/>}
                  </div>
                );
              })}
            </div>

            {/* Summary card */}
            {done && mode==="pipeline" && seoOut && (
              <div style={{ background:T.navyMid, borderRadius:10,
                border:`1px solid ${T.green}30`, padding:13, animation:"kfadeup .4s ease" }}>
                <div style={{ fontSize:9.5, fontWeight:700, color:T.green,
                  letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:11 }}>Output summary</div>
                {[
                  ["SEO score",   `${seoOut?.total_score||"—"}/100`],
                  ["Title tag",   (seoOut?.title_tag||"—").slice(0,32)+(seoOut?.title_tag?.length>32?"…":"")],
                  ["Slug",        seoOut?.slug||"—"],
                  ["Fact check",  fcOut?.verdict||"—"],
                  ["Readability", seoOut?.readability_grade||"—"],
                  ["Word count",  `${(wOut||"").split(" ").filter(Boolean).length} words`],
                ].map(([k,v]) => (
                  <div key={k} style={{ display:"flex", justifyContent:"space-between",
                    padding:"5px 0", borderBottom:`1px solid ${T.border}`, fontSize:10 }}>
                    <span style={{ color:T.muted }}>{k}</span>
                    <span style={{ color:T.white, fontWeight:600 }}>{v}</span>
                  </div>
                ))}
                {seoOut?.total_score && (
                  <div style={{ marginTop:10 }}>
                    <ScoreBar value={seoOut.total_score}/>
                  </div>
                )}
              </div>
            )}

            {/* Architecture */}
            <div style={{ background:T.navyMid, borderRadius:10, border:`1px solid ${T.border}`, padding:13 }}>
              <div style={{ fontSize:9.5, fontWeight:700, color:T.teal,
                letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:11 }}>Architecture</div>
              {[
                ["Model",      "claude-sonnet-4-20250514"],
                ["Agents",     "7 specialised agents"],
                ["Research",   "SERP reverse-engineering (B)"],
                ["Strategy",   "Brief before writing (A)"],
                ["Scale",      "Cluster + pillar model (C)"],
                ["Refresh",    "Monthly SERP re-scan"],
                ["API route",  "/api/claude (edge fn)"],
              ].map(([k,v]) => (
                <div key={k} style={{ display:"flex", justifyContent:"space-between",
                  padding:"5px 0", borderBottom:`1px solid ${T.border}`, fontSize:9.5 }}>
                  <span style={{ color:T.muted }}>{k}</span>
                  <span style={{ color:T.silver, fontWeight:600, textAlign:"right",
                    maxWidth:160 }}>{v}</span>
                </div>
              ))}
            </div>

          </div>
        </div>

        {/* Footer */}
        <div style={{ maxWidth:920, margin:"20px auto 0", textAlign:"center",
          fontSize:9.5, color:T.muted, paddingTop:14,
          borderTop:`1px solid ${T.border}` }}>
          Kalpi SEO Engine · claude-sonnet-4-20250514 · Vercel Edge Functions · Assignment submission
        </div>
      </div>
    </>
  );
}
